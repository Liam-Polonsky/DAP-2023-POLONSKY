package com.MusicApp.AppMusic.TerceraPantalla

import androidx.lifecycle.ViewModel

class InicioViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}