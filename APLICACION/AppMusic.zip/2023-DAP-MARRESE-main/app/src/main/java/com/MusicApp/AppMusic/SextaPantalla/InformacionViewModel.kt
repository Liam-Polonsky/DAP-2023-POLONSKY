package com.MusicApp.AppMusic.SextaPantalla

import androidx.lifecycle.ViewModel

class InformacionViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}