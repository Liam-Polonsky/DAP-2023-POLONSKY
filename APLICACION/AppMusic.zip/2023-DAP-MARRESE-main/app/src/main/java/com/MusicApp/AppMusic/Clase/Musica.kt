package com.MusicApp.AppMusic.Clase

data class Musica (
    var cancion:String? = null ,
    var cantante:String? = null ,
    var año:String? = null,
    var idFirebase:String? = null,
)