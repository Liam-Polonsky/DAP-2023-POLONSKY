package com.MusicApp.AppMusic.PrimeraPantalla

import androidx.lifecycle.ViewModel

class LoginViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}