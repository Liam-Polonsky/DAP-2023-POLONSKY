package com.MusicApp.AppMusic.CuartaPantalla

import androidx.lifecycle.ViewModel

class CrearViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}