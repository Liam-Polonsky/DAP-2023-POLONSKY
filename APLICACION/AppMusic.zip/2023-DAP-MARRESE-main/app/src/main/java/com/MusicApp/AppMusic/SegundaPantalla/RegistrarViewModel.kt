package com.MusicApp.AppMusic.SegundaPantalla

import androidx.lifecycle.ViewModel

class RegistrarViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}