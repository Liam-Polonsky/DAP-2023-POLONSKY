package com.MusicApp.AppMusic.QuintaPantalla

import androidx.lifecycle.ViewModel

class EditarViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}